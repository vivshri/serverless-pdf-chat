"""Tavily Search API toolkit."""

from langchain.tools.tavily_search.tool import TavilySearchResults

__all__ = ["TavilySearchResults"]
